package shapes;

public class CircleException extends Exception{
    public CircleException(){
        super("Invalid radius!");
    }
}
