package shapes;

public class SquareException extends Exception{
    public SquareException(){
        super("Invalid side!");
    }
}
