package shapes;

public class TriangleException extends Exception {
    public TriangleException(){
        super("Invalid side(s)!");
    }
}
