package shapes;

public class ParallelogramException extends Exception{
    public ParallelogramException(){
        super("Invalid side(s)!");
    }
}
